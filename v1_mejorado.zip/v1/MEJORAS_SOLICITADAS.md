# Mejoras solicitadas

- El primer control ahora aparece como **Pecho Alto + Cuello Avatar**.
- Se añadió margen superior al encabezado del menú External para bajar el cuadro/logo y evitar que la Dynamic Island lo tape.
- Se añadieron mensajes de interfaz para los códigos de error de licencia:
  - `device_mismatch` → `KEY USED POR OTRO DISPOSITIVO`
  - `banned`, `key_banned` o `ban` → `ESTA KEY FUE BANEADA`
  - `device_limit`, `max_devices`, `max_devices_reached` o `device_limit_reached` → `LA KEY ALCANZÓ SUS MAX DE DISPOSITIVOS`

## Importante sobre las keys

La app solo puede mostrar los mensajes de baneo y límite de dispositivos si el servidor HTTPS de licencias devuelve esos códigos en `error`. El servidor externo no forma parte de este ZIP, por lo que estos cambios de cliente no crean ni modifican por sí solos las reglas de licenciamiento. Configura esos códigos en el backend antes de usarlo en producción.

El ZIP contiene el código fuente; no incluye una IPA firmada. Para compilar y firmar se necesita Xcode en macOS y el certificado/perfil correspondiente.
