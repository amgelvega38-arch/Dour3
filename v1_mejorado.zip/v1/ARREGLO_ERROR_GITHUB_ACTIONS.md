# Corrección del error de descompresión en GitHub Actions

El error `End-of-central-directory signature not found` ocurre cuando el workflow intenta ejecutar `unzip` sobre un archivo que no es un ZIP válido o cuando el repositorio contiene más de un ZIP y el patrón `*.zip` selecciona el archivo equivocado.

Esta versión elimina por completo ese paso. El workflow `.github/workflows/build-ipa.yml` compila directamente `ThreeOneOSFive.xcodeproj` con Xcode en macOS y después empaqueta el `.app` generado como un IPA sin firma.

## Cómo usarlo

1. Descomprime este proyecto en tu dispositivo o computadora.
2. Sube el **contenido** del ZIP al repositorio de GitHub, conservando `.github/workflows/build-ipa.yml` y `ThreeOneOSFive.xcodeproj` en la raíz.
3. En GitHub, abre **Actions** y ejecuta **Panther iOS - IPA sin firmar**.
4. Descarga el artefacto `Panther-iOS-unsigned` cuando termine correctamente.

Si el repositorio ya tiene otro workflow que contiene `unzip -o *.zip -d proyecto`, elimínalo o desactívalo para que no siga ejecutándose en paralelo. No subas el ZIP como un archivo único dentro del repositorio: GitHub Actions necesita ver la carpeta `.xcodeproj` directamente.

El IPA es sin firma; instalarlo en un iPhone requiere un método de firma compatible.
